package networks;

import java.io.*; 
import java.net.*; 
public class TCPClient {
	static Socket clientSocket;
	    public static void main(String argv[]) throws Exception 
	    { 
	        String input; 
	        String modifiedSentence; 
	        BufferedReader inFromUser = 
	          new BufferedReader(new InputStreamReader(System.in));   
	        input = inFromUser.readLine(); 
            if(input.equals("CONNECT")){
		        clientSocket = new Socket("127.1.1.0", 6789);
		        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream()); 
		        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); 
        	  System.out.print("FROM CLIENT: "); 
        	  input = inFromUser.readLine();
	          outToServer.writeBytes(input + '\n');     	  
        	  while(true){
        		  modifiedSentence = inFromServer.readLine();
		          System.out.println("FROM SERVER: " + modifiedSentence);
		          
		          System.out.print("FROM CLIENT: "); 
        		  input = inFromUser.readLine();
        		  if(input.equals("remove")){
    		          outToServer.writeBytes(input + '\n'); 
    		          outToServer.close();
    		          break;
        		  }
		          outToServer.writeBytes(input + '\n'); 
        	  }
          	
            }
           
          else{
        	  System.out.println("could not connect write CONNECT RIGHT");
	      }
	 } 
}

package networks;
import java.io.*; 
import java.net.*;
public class TCPServer {
static Socket connectionSocket;
	public static void main(String argv[]) throws Exception 
    { 
      String clientinput; 
      String output; 

      ServerSocket welcomeSocket = new ServerSocket(6789); 
            connectionSocket = welcomeSocket.accept(); 
            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
					BufferedReader inFromClient;
              
           DataOutputStream  outToClient;
					while(true){
					inFromClient = 
              new BufferedReader(new
              InputStreamReader(connectionSocket.getInputStream()));
              
              outToClient = 
                   new DataOutputStream(connectionSocket.getOutputStream());
					
					clientinput = inFromClient.readLine();
                 System.out.println("From Client: " + clientinput);
                 if(clientinput.equals("remove")){
									outToClient.close();
									break;
								}

								 System.out.print("From Server: ");
                 output = inFromUser.readLine() + '\n';
                 
                 System.out.print(output);

                 outToClient.writeBytes(output);
					}
			}
}
